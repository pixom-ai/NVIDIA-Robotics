# Edge Detection

This example demonstrates how to subscribe to the raw camera images, process those images using Canny Edge Detection, and publish the resulting image to a new topic.  While running this example, navigate to the dashboard in a webbrowser and select `/user/image1` from the Video Source dropdown.


