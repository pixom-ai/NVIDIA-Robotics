# Circle Counting

This example demonstrates how to subscribe to the raw camera images and count circles using the Hough Transform.  While running this example, navigate to the dashboard in a webbrowser and select `/user/image1` from the Video Source dropdown.


