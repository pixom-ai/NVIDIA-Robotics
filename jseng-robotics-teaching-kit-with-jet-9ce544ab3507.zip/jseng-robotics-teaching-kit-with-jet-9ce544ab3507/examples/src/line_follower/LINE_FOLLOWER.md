# Line Follower

This example uses blurs, Canny Edge Detection, and Hough Lines Transform to help the robot follow lines on the ground.  It also outputs a visual representation of its computer vision code to user_image1 topic.
