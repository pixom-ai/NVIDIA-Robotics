# Sense and Avoid

This example demonstrates the use of sonar to detect obstacles.  When an object is detected, the robot backs up and turns right before continuing.  The encoders are used to determine how far the robot has traveled.  
