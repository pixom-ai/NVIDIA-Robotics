# Face Follower

This example demonstrates how to use GPU accelerated HAAR Cascade Classifiers, to detect and track a face.  While running this example, navigate to the dashboard in a webbrowser and select `/user/image1` from the Video Source dropdown.


