# Module 9: Questions

1. What are some limitations of aerial maps?

2. What is the method of detecting overlapping images in image stitching that was discussed in lecture?

3. What class in OpenCV is used for stitching images or maps together?

4. What are some examples of information that can be included in maps that is not present in traditional aerial images?

5. Name three tools or techniques that can be used to generate point clouds.

6. What are the two things that SLAM is trying to maximize the likelihood of?

7. Why are particle filters often preferred to Kalman Filters for SLAM?

8. What are the attributes of a good landmark?

9. What causes the Loop Closure problem?

10. Why is it difficult to use a Monocular camera for SLAM?
