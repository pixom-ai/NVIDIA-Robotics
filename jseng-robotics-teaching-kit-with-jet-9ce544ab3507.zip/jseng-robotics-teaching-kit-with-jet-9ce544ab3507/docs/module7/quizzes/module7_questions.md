# Module 7: Questions

1.  Give an example of a control system.  What is the controller, sensor, and output?

2.  Why are Open-Loop control systems used infrequently in industrial and manufacturing plants?

3.  What are the two techniques used to transform time-domain signals to the frequency domain?

4.  If a control system oscillates rapidly for a while before converging, what is the damping of the system?

5.  What type of damping will result the fastest convergence to the reference?

6.  What do PID control systems minimize?

7.  What is the purpose of the derivative term in PID control?

8.  What is the purpose of the integral term in PID control?

9.  What is the name of a manual approach to finding parameters for PID controller?

10.  What is a limitation of PID control?
