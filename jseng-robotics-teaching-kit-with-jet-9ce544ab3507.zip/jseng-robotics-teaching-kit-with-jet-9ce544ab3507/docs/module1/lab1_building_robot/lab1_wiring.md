This file describes how to solder and connect the wires


![](module1/lab1_building_robot/resources/wiring/schematic.png)
