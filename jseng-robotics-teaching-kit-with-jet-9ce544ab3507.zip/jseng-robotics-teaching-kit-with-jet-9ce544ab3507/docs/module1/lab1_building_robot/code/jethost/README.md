# jethost

The ROS nodes that run on a host computer for interacting with Jet.

Consult INSTALLATION.md for how to setup jethost.

## Running Simulations

`roslaunch jet_gazebo jet_gazebo.launch`
