# Module 1: Questions

1. What types of computing cores are available on the Jetson TK1?

2. How can you remotely connect to the Jetson TK1?

3. Describe the reasons for having the Arduino Mega run alongside the TK1.

4. What components are directly connected to the battery?

5. Describe the capabilities of ROS nodes.

6. What does it mean for ROS Topics to be 'strongly typed'?

7. What command is used to clean out any recently compiled ROS nodes?

8. Describe the relationship between the Ubuntu Linux OS and ROS.

9. How are ROS nodes started?

10. How can you know what topics are available on a ROS system?
