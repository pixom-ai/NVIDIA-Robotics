# Module 2: Questions

1. What is the farthest distance the Jet sonar module can measure?

2. Tablets and cellphones can detect whether they are being used in a portrait or landscape
   orientation.  What sensor is used to detect this?

3. What does a gyroscope measure?

4. The Jet encoders can detect 3200 ticks per revolution.  If a wheel has moved 1000 ticks
   forward and Jet has 6 inch diameter wheels, how many inches has the robot moved forward?

5. Explain why the motors cannot be directly connected to the Jetson TK1.

6. How do you read the encoder values?

7. Describe the reason for the 6-pin connector on the Jet motors.

8. Describe the reason for the 4-pin connector on the sonar module.

9. You would like to measure how bumpy or smooth the ground is that Jet is running on.  What
   sensor would be best suited for this?

10. What is gyroscope drift?
